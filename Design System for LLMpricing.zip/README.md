
  # Design System for LLMpricing

  This is a code bundle for Design System for LLMpricing. The original project is available at https://www.figma.com/design/FVJ38CmvANxI5bvh2JAjBM/Design-System-for-LLMpricing.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  